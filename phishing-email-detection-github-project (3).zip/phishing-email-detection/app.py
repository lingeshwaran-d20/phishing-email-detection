import re
from pathlib import Path

import joblib
import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer  # Needed when loading the saved pipeline
from sklearn.linear_model import LogisticRegression         # Needed when loading the saved pipeline

from train_model import add_feature_tokens

ROOT = Path(__file__).parent
MODEL_PATH = ROOT / "phishing_model.joblib"
DATA_PATH = ROOT / "data" / "emails.csv"

st.set_page_config(page_title="Phishing Email Detector", page_icon="🛡️", layout="centered")
st.title("🛡️ Phishing Email Detection")
st.write("Paste an email below to check whether its text resembles phishing or safe examples.")

@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        return None
    return joblib.load(MODEL_PATH)

model = load_model()

if model is None:
    st.warning("The trained model was not found. Train it first by running: `python train_model.py`")
else:
    email_text = st.text_area(
        "Email content",
        height=220,
        placeholder="Paste the email subject and body here. Do not include real passwords or private information."
    )
    if st.button("Analyze email", type="primary", use_container_width=True):
        if not email_text.strip():
            st.error("Please paste some email text first.")
        else:
            prepared = add_feature_tokens(email_text)
            prediction = model.predict([prepared])[0]
            probabilities = model.predict_proba([prepared])[0]
            class_probabilities = dict(zip(model.classes_, probabilities))
            confidence = class_probabilities.get(prediction, max(probabilities))

            if prediction == "phishing":
                st.error(f"Result: POSSIBLE PHISHING — model confidence {confidence:.1%}")
            else:
                st.success(f"Result: LIKELY SAFE — model confidence {confidence:.1%}")

            st.caption("This is a machine-learning estimate, not a guarantee. Check links and sender details yourself.")
            with st.expander("Signals found in the email"):
                urls = re.findall(r"https?://\S+|www\.\S+", email_text, flags=re.IGNORECASE)
                st.write(f"URLs detected: {len(urls)}")
                if urls:
                    st.write("Detected URL text:")
                    for url in urls[:10]:
                        st.code(url)
                checks = {
                    "Login/account wording": bool(re.search(r"\b(login|sign in|verify|password|account|credentials)\b", email_text, re.I)),
                    "Urgency wording": bool(re.search(r"\b(urgent|immediately|suspended|expires today|act now)\b", email_text, re.I)),
                    "Prize wording": bool(re.search(r"\b(prize|winner|claim your|free gift|lottery)\b", email_text, re.I)),
                    "Financial wording": bool(re.search(r"\b(bank|payment|invoice|refund|transfer)\b", email_text, re.I)),
                    "IP address in URL": bool(re.search(r"https?://(?:\d{1,3}\.){3}\d{1,3}", email_text, re.I)),
                }
                for label, found in checks.items():
                    st.write(("⚠️ " if found else "✓ ") + label + (": found" if found else ": not found"))

st.divider()
st.subheader("Model evaluation")
if DATA_PATH.exists():
    data = pd.read_csv(DATA_PATH)
    st.write(f"Included sample dataset: **{len(data)} emails**")
    st.info("Run `python train_model.py` in the terminal to print the test accuracy, classification report, and confusion matrix.")
else:
    st.info("Add a labeled CSV dataset at `data/emails.csv` to train and evaluate the model.")

st.caption("Educational project only. Do not use this model as the sole basis for security decisions.")
