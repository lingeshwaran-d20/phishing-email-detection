import re
from pathlib import Path

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

DATA_PATH = Path(__file__).parent / "data" / "emails.csv"
MODEL_PATH = Path(__file__).parent / "phishing_model.joblib"


def add_feature_tokens(email_text):
    """Append simple, explainable signals to the email text for the text model."""
    text = str(email_text)
    lower = text.lower()
    tokens = []

    urls = re.findall(r"https?://\S+|www\.\S+", text, flags=re.IGNORECASE)
    if urls:
        tokens.append("FEATURE_HAS_URL")
    if len(urls) > 1:
        tokens.append("FEATURE_MULTIPLE_URLS")
    if re.search(r"https?://(?:\d{1,3}\.){3}\d{1,3}", text, re.IGNORECASE):
        tokens.append("FEATURE_IP_ADDRESS_URL")
    if re.search(r"\b(login|sign in|verify|password|account|credentials)\b", lower):
        tokens.append("FEATURE_ACCOUNT_OR_LOGIN_WORDS")
    if re.search(r"\b(urgent|immediately|suspended|expires today|act now)\b", lower):
        tokens.append("FEATURE_URGENCY_WORDS")
    if re.search(r"\b(prize|winner|claim your|free gift|lottery)\b", lower):
        tokens.append("FEATURE_PRIZE_WORDS")
    if re.search(r"\b(bank|payment|invoice|refund|transfer)\b", lower):
        tokens.append("FEATURE_FINANCIAL_WORDS")
    if re.search(r"\.(zip|top|xyz|click|work|gq|tk)(?:[/:\s]|$)", lower):
        tokens.append("FEATURE_UNCOMMON_DOMAIN_SUFFIX")
    return text + " " + " ".join(tokens)


def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")

    data = pd.read_csv(DATA_PATH)
    required = {"email_text", "label"}
    if not required.issubset(data.columns):
        raise ValueError("CSV must contain 'email_text' and 'label' columns.")

    data = data.dropna(subset=["email_text", "label"])
    data["label"] = data["label"].astype(str).str.lower().str.strip()
    data = data[data["label"].isin(["phishing", "safe"])]
    if data["label"].nunique() < 2:
        raise ValueError("Dataset must contain both 'phishing' and 'safe' labels.")

    X = data["email_text"].astype(str).map(add_feature_tokens)
    y = data["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    model = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=5000, stop_words="english")),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
    ])
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    print(f"\nTest accuracy: {accuracy:.2%}")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, zero_division=0))
    print("Confusion matrix (rows = actual, columns = predicted):")
    print("Labels:", list(model.classes_))
    print(confusion_matrix(y_test, predictions, labels=model.classes_))

    try:
        import joblib
        joblib.dump(model, MODEL_PATH)
        print(f"\nSaved model to: {MODEL_PATH}")
    except Exception as exc:
        print(f"\nModel was trained, but could not be saved: {exc}")


if __name__ == "__main__":
    main()
