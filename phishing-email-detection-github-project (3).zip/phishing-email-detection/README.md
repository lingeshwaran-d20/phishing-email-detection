# Phishing Email Detection Model

A beginner-friendly machine-learning project that classifies email text as **Phishing** or **Safe** using Python and Scikit-learn. It includes a small sample dataset, an interactive Streamlit interface, text-based signals, and model evaluation.

## Features

- Trains a TF-IDF + Logistic Regression text classifier.
- Adds simple signals for URLs, login/account wording, urgency, prize wording, financial wording, IP-address URLs, and uncommon domain suffixes.
- Predicts whether pasted email text resembles phishing or safe examples.
- Shows a test accuracy, classification report, and confusion matrix in the terminal.
- Includes a small sample dataset so the project can run immediately.

## Project structure

```text
phishing-email-detection/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── .gitignore
└── data/
    └── emails.csv
```

## 1. Install Python

Install Python 3.10 or newer. During Windows installation, select **Add Python to PATH**.

## 2. Open the project in VS Code

Extract this folder, then open it in VS Code using **File → Open Folder**.

## 3. Create a virtual environment (recommended)

Windows PowerShell:

```powershell
python -m venv .venv
.venv\\Scripts\\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```bat
.venv\\Scripts\\activate.bat
```

## 4. Install the libraries

```bash
python -m pip install -r requirements.txt
```

## 5. Train the model

```bash
python train_model.py
```

The program prints test accuracy, precision/recall/F1 scores, and a confusion matrix. It also saves `phishing_model.joblib`.

**Important:** the included dataset is small and created for learning/demo purposes. Its accuracy is not a real-world performance estimate. For a serious evaluation, use a larger, trusted, labeled dataset and test on emails that were not used during model development.

## 6. Run the web app

```bash
streamlit run app.py
```

A browser tab should open. Paste sample email text and select **Analyze email**.

## Dataset format

`data/emails.csv` must contain these columns:

- `email_text`: email subject/body text
- `label`: either `phishing` or `safe`

Example:

```csv
email_text,label
"Your account is locked. Verify your password at http://example.invalid/login",phishing
"Hi team, our meeting is scheduled for 2 PM tomorrow.",safe
```

Only use datasets you have permission to use. Remove personal data before training.

## Upload to GitHub

1. Create a new repository on GitHub, for example `phishing-email-detection`.
2. Open the project folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run the commands below (replace the URL with your repository URL):

```bash
git init
git add .
git commit -m "Add phishing email detection project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/phishing-email-detection.git
git push -u origin main
```

If Git asks you to sign in, follow the sign-in prompts. Do not upload passwords, API keys, private emails, or other confidential information.

## Limitations and safety

- The sample dataset is small and illustrative; the model can make mistakes.
- A “Safe” result does not prove an email is safe. Attackers can change wording and domains.
- Do not click suspicious links to test them.
- Do not paste confidential messages into the demo app.
- This project is for education and should not replace email security software or human review.
